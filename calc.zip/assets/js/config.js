const JSONBIN_URL = "https://api.jsonbin.io/v3/b/67ed40378561e97a50f76529"; 
const JSONBIN_API_KEY ="$2a$10$sMazlu4kQGQ35/5z7Zw9L.qtvOGra/VKzwdSfG.teNNY6ro9E3kQG";
const API_BASE = "https://api.coingecko.com/api/v3";