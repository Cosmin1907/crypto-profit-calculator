const JSONBIN_URL = "https://api.jsonbin.io/v3/b/67ed40378561e97a50f76529"; 
const JSONBIN_API_KEY ="$2a$10$sMazlu4kQGQ35/5z7Zw9L.qtvOGra/VKzwdSfG.teNNY6ro9E3kQG";
const API_BASE = "https://api.coingecko.com/api/v3";

// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyDUBCzM4o9bkSc4VNKaqrh8sD3VeghmG4Y",
    authDomain: "crypto-calculator-357af.firebaseapp.com",
    databaseURL: "https://crypto-calculator-357af-default-rtdb.europe-west1.firebasedatabase.app",
    projectId: "crypto-calculator-357af",
    storageBucket: "crypto-calculator-357af.appspot.com",
    messagingSenderId: "813749364439",
    appId: "1:813749364439:web:76d6b01ba1ae007c04f292",
    measurementId: "G-08S7189TYG"
  };
  
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  
  // Initialize Realtime Database
  const database = firebase.database();

  
  